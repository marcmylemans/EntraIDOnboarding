# MO Onboarding/Offboarding — Solution Skeleton v2

See docs and flows folder for details.
