# Import Guide

1) Run deploy scripts.
2) Create env vars.
3) Build flows or follow flows/ markdown.
4) Export as Managed.
