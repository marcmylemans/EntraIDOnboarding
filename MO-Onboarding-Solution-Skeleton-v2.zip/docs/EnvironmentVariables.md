# Environment Variables

See prior message for the list; same names apply.
